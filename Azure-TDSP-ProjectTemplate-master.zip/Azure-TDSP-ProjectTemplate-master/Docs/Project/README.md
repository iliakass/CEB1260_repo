# Folder for hosting project documents and reports for a Data Science Project

These could be: 

1. Project management and planning docs
2. System architecture
3. Information obtained from a business owner or client about the project
4. Docs and presentations prepared to share information about hte project

In this folder we have templates for project chater and exit report. 

In addition, if you have access to Microsoft Project or Excel, you may use project templates provided in this [blog](https://blogs.msdn.microsoft.com/buckwoody/2017/10/24/a-data-science-microsoft-project-template-you-can-use-in-your-solutions).
